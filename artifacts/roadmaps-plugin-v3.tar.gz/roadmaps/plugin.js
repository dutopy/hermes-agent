/**
 * Roadmaps — disk-mode Desktop plugin (work-in-progress, branch feat/overview-roadmaps).
 *
 * Vertical slice THREAD + MAP + INSPECTOR over the real `roadmaps.*` JSON-RPC
 * surface of the gateway (host.request). No fixtures, no local SQL, no
 * optimistic cache mutation — every write reloads an authoritative snapshot.
 *
 * Manual steering: node claim/progress/complete/block/unblock + todo
 * start/finish/cancel/reopen, all through versioned mutations.
 *
 * Disk contract: plain ESM, imports limited to @hermes/plugin-sdk,
 * react, react/jsx-runtime; UI written with jsx()/jsxs() (not compiled).
 */

import {
  Badge,
  Button,
  Codicon,
  CopyButton,
  EmptyState,
  ErrorState,
  Input,
  ROUTES_AREA,
  ScrollArea,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Separator,
  SIDEBAR_NAV_AREA,
  Skeleton,
  StatusDot,
  Tip,
  cn,
  host,
  useQuery,
  useValue
} from '@hermes/plugin-sdk'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { jsx, jsxs } from 'react/jsx-runtime'

// ── constants / helpers ─────────────────────────────────────────────────────

const ID = 'roadmaps'

/** Semantic tones per node lifecycle state (StatusDot tones only). */
const NODE_TONE = {
  ready: 'good',
  in_progress: 'warn',
  blocked: 'bad',
  completed: 'muted',
  cancelled: 'muted'
}

const NODE_ORDER = { blocked: 0, in_progress: 1, ready: 2 }

const NODE_STATE_LABEL = {
  ready: 'Ready',
  in_progress: 'In progress',
  blocked: 'Blocked',
  completed: 'Completed',
  planned: 'Planned',
  archived: 'Archived'
}

/** Mutation error codes → actionable copy. 5064/5066 get explicit guidance. */
const MUTATION_ERRORS = {
  5063: { title: 'Invalid parameters', hint: 'Check the scope (profile/project/roadmap) and the fields you entered.' },
  5064: {
    title: 'Stale version',
    hint: 'The roadmap changed since your snapshot. Reload the snapshot, then retry the action.'
  },
  5065: { title: 'Not found', hint: 'The roadmap, node or todo no longer exists in this scope. Reload the list.' },
  5066: {
    title: 'Invalid transition',
    hint: "The current state does not allow this action (e.g. completing a blocked node). Fix the state, then retry."
  },
  5061: { title: 'Service unavailable', hint: 'The roadmaps backend is temporarily unavailable. Retry.' }
}

/** Extract {code, message} from a host.request rejection (JSON-RPC error). */
function rpcError(err) {
  const code = typeof err?.code === 'number' ? err.code : Number(err?.code)
  return {
    code: Number.isFinite(code) ? code : null,
    message: typeof err?.message === 'string' ? err.message : String(err ?? 'unknown error')
  }
}

// ── data layer (pure functions over the snapshot) ───────────────────────────

function activeVersion(snapshot) {
  const roadmap = snapshot?.roadmap
  const v = roadmap?.active_version
  return roadmap?.versions?.find((x) => x.version === v) ?? null
}

/** Thread: actionable nodes, blocked first, then in_progress, then ready. */
function threadNodes(version) {
  const nodes = version?.nodes ?? []
  return nodes
    .filter((n) => n.state === 'ready' || n.state === 'in_progress' || n.state === 'blocked')
    .sort(
      (a, b) =>
        (NODE_ORDER[a.state] ?? 9) - (NODE_ORDER[b.state] ?? 9) || String(a.node_id).localeCompare(String(b.node_id))
    )
}

/** Map: canonical relations of the active version (active by default). */
function mapRelations(version, { includeInactive = false } = {}) {
  const nodes = version?.nodes ?? []
  const byId = new Map(nodes.map((n) => [n.node_id, n]))
  return (version?.relations ?? [])
    .filter((r) => includeInactive || r.state === 'active')
    .filter((r) => CANONICAL_RELATIONS.has(r.kind))
    .map((r) => ({ ...r, from: byId.get(r.from_node_id) ?? null, to: byId.get(r.to_node_id) ?? null }))
    .filter((r) => r.from && r.to)
    .sort((a, b) => String(a.relation_id).localeCompare(String(b.relation_id)))
}

const CANONICAL_RELATIONS = new Set(['depends_on', 'blocks'])

/** Display label: prefer the human title, fall back to the id. */
const nodeLabel = (n) => n?.title || n?.node_id || '?'

// ── small presentational pieces ─────────────────────────────────────────────

function NodeStateBadge({ state }) {
  return jsxs(Badge, {
    size: 'xs',
    variant:
      state === 'blocked' ? 'destructive' : state === 'completed' ? 'muted' : state === 'in_progress' ? 'warn' : 'outline',
    children: [jsx(StatusDot, { tone: NODE_TONE[state] ?? 'muted' }), jsx('span', { children: NODE_STATE_LABEL[state] ?? state })]
  })
}

function ProgressBar({ value }) {
  const pct = Math.max(0, Math.min(100, Number.isFinite(value) ? value : 0))
  return jsxs('div', {
    className: 'flex items-center gap-2',
    children: [
      jsxs('div', {
        className: 'h-1 w-16 overflow-hidden rounded-full bg-(--ui-stroke-secondary)',
        children: [jsx('div', { className: 'h-full rounded-full bg-primary transition-all', style: { width: `${pct}%` } })]
      }),
      jsx('span', { className: 'text-[0.65rem] tabular-nums text-muted-foreground', children: `${pct}%` })
    ]
  })
}

function SectionTitle({ children, right }) {
  return jsxs('div', {
    className: 'flex items-center justify-between px-1 text-[0.65rem] font-medium uppercase tracking-wide text-muted-foreground',
    children: [jsx('span', { children }), right ?? null]
  })
}

// ── THREAD — "what should I do now?" ────────────────────────────────────────

function NodeRow({ node, selected, onSelect, compact }) {
  const onClick = useCallback(() => onSelect(node.node_id), [node.node_id, onSelect])

  return jsxs('button', {
    type: 'button',
    onClick,
    className: cn(
      'group w-full rounded-md border px-2 py-1.5 text-left transition-colors',
      selected ? 'border-(--ui-accent) bg-primary/10' : 'border-(--ui-stroke-secondary) hover:bg-(--chrome-action-hover)'
    ),
    children: [
      jsxs('div', {
        className: 'flex items-center gap-2',
        children: [
          jsx(StatusDot, { tone: NODE_TONE[node.state] ?? 'muted' }),
          jsxs('span', {
            className: 'min-w-0 flex-1 truncate text-xs font-medium',
            children: [jsx('span', { className: 'text-muted-foreground', children: `${node.kind} · ` }), nodeLabel(node)]
          }),
          !compact ? jsx(NodeStateBadge, { state: node.state }) : null
        ]
      }),
      !compact
        ? jsxs('div', {
            className: 'mt-1 flex items-center gap-3 pl-3.5',
            children: [
              node.owner_agent
                ? jsxs('span', {
                    className: 'truncate text-[0.65rem] text-muted-foreground',
                    children: [jsx(Codicon, { name: 'person', size: '0.65rem', className: 'mr-0.5 inline align-[-1px]' }), node.owner_agent]
                  })
                : null,
              jsx(ProgressBar, { value: node.progress })
            ]
          })
        : null,
      node.state === 'blocked' && node.block_reason
        ? jsxs('div', {
            className: 'mt-1 flex items-start gap-1 pl-3.5 text-[0.65rem] text-destructive',
            children: [
              jsx(Codicon, { name: 'debug-disconnect', size: '0.7rem', className: 'mt-px shrink-0' }),
              jsx('span', { className: 'whitespace-pre-wrap break-words', children: node.block_reason })
            ]
          })
        : null
    ]
  })
}

function ThreadView({ version, selectedId, onSelect, compact }) {
  const nodes = threadNodes(version)

  if (nodes.length === 0) {
    return jsx(EmptyState, {
      title: 'Nothing to do right now',
      description: 'No ready / in_progress / blocked node in the active version of this roadmap.'
    })
  }

  return jsxs('div', {
    className: 'flex flex-col gap-1',
    children: [
      jsx(SectionTitle, { children: 'What should I do now?' }),
      nodes.map((n) => jsx(NodeRow, { node: n, selected: n.node_id === selectedId, onSelect, compact }, n.node_id))
    ]
  })
}

// ── MAP — canonical relations ───────────────────────────────────────────────

const RELATION_LABEL = { depends_on: 'depends on', blocks: 'blocks' }

function RelationRow({ rel, selectedNodeId, onSelect }) {
  const highlights = rel.from_node_id === selectedNodeId || rel.to_node_id === selectedNodeId
  const onFrom = useCallback(() => onSelect(rel.from_node_id), [rel.from_node_id, onSelect])
  const onTo = useCallback(() => onSelect(rel.to_node_id), [rel.to_node_id, onSelect])

  return jsxs('div', {
    className: cn(
      'flex items-center gap-2 rounded-md border px-2 py-1.5 text-xs',
      highlights ? 'border-(--ui-accent) bg-primary/10' : 'border-(--ui-stroke-secondary)'
    ),
    children: [
      jsxs('button', {
        type: 'button',
        onClick: onFrom,
        className: 'min-w-0 flex-1 truncate text-left hover:underline',
        children: nodeLabel(rel.from)
      }),
      jsxs('span', {
        className: 'flex shrink-0 items-center gap-1 text-[0.65rem] text-muted-foreground',
        children: [
          jsx(Codicon, { name: rel.kind === 'blocks' ? 'debug-disconnect' : 'arrow-right', size: '0.7rem' }),
          RELATION_LABEL[rel.kind] ?? rel.kind
        ]
      }),
      jsxs('button', {
        type: 'button',
        onClick: onTo,
        className: 'min-w-0 flex-1 truncate text-right hover:underline',
        children: nodeLabel(rel.to)
      })
    ]
  })
}

function MapView({ version, selectedId, onSelect }) {
  const [showInactive, setShowInactive] = useState(false)
  const rels = useMemo(() => mapRelations(version, { includeInactive: showInactive }), [version, showInactive])

  return jsxs('div', {
    className: 'flex flex-col gap-1',
    children: [
      jsxs(SectionTitle, {
        right: jsx('button', {
          type: 'button',
          onClick: () => setShowInactive((v) => !v),
          className: 'rounded px-1 text-[0.6rem] text-muted-foreground hover:bg-(--chrome-action-hover)',
          children: showInactive ? 'active relations' : 'include inactive'
        }),
        children: ['Relations of the active version', ` (${rels.length})`]
      }),
      rels.length === 0
        ? jsx(EmptyState, {
            title: showInactive ? 'No relations' : 'No active relations',
            description: 'Each row is a canonical relation (depends_on, blocks) of the active version.'
          })
        : rels.map((r) => jsx(RelationRow, { rel: r, selectedNodeId: selectedId, onSelect }, r.relation_id))
    ]
  })
}

// ── INSPECTOR — details + manual steering mutations ─────────────────────────

function MutationButton({ label, codicon, onClick, busy, disabled, tone }) {
  return jsxs(Button, {
    type: 'button',
    variant: tone === 'danger' ? 'destructive' : 'secondary',
    size: 'xs',
    onClick,
    disabled: disabled || busy,
    className: 'gap-1',
    children: [jsx(Codicon, { name: codicon, size: '0.75rem' }), label]
  })
}

function TodoRow({ todo, onMutate, busyTodoId }) {
  const done = todo.state === 'done' || todo.state === 'cancelled'
  return jsxs('div', {
    className: 'flex items-center gap-2 text-xs',
    children: [
      jsx(StatusDot, { tone: done ? 'muted' : 'good' }),
      jsx('span', {
        className: cn('min-w-0 flex-1 truncate', done && 'line-through opacity-60'),
        children: todo.title
      }),
      jsxs('div', { className: 'flex shrink-0 items-center gap-1', children: [
        todo.state === 'open'
          ? jsx(MutationButton, {
              label: 'Start',
              codicon: 'play',
              onClick: () => onMutate(todo.todo_id, 'in_progress'),
              busy: busyTodoId === todo.todo_id
            })
          : null,
        todo.state === 'in_progress'
          ? jsx(MutationButton, {
              label: 'Finish',
              codicon: 'pass-filled',
              onClick: () => onMutate(todo.todo_id, 'done'),
              busy: busyTodoId === todo.todo_id
            })
          : null,
        !done
          ? jsx(MutationButton, {
              label: 'Cancel',
              codicon: 'close',
              onClick: () => onMutate(todo.todo_id, 'cancelled'),
              busy: busyTodoId === todo.todo_id,
              tone: 'danger'
            })
          : null,
        todo.state === 'cancelled'
          ? jsx(MutationButton, {
              label: 'Reopen',
              codicon: 'debug-restart',
              onClick: () => onMutate(todo.todo_id, 'open'),
              busy: busyTodoId === todo.todo_id
            })
          : null
      ] })
    ]
  })
}

function Inspector({ snapshot, version, nodeId, scope, onMutated, compact, actor, setActor }) {
  const [progressInput, setProgressInput] = useState('')
  const [reason, setReason] = useState('')
  const [busyOp, setBusyOp] = useState(null)
  const [busyTodoId, setBusyTodoId] = useState(null)
  const [error, setError] = useState(null)

  const node = (version?.nodes ?? []).find((n) => n.node_id === nodeId) ?? null
  const todos = (version?.todos ?? []).filter((t) => t.node_id === nodeId)
  const expectedVersion = snapshot?.roadmap?.active_version

  // Reset transient form/error state when the inspected node changes.
  useEffect(() => {
    setProgressInput('')
    setReason('')
    setError(null)
  }, [nodeId])

  const mutate = useCallback(
    async (op, extra) => {
      if (!node || !scope) return
      setBusyOp(op)
      setError(null)
      try {
        await host.request(`roadmaps.${op}`, {
          profile: scope.profile,
          project_id: scope.projectId,
          roadmap_id: scope.roadmapId,
          node_id: node.node_id,
          actor: actor.trim() || 'user',
          expected_version: expectedVersion,
          ...(extra ?? {})
        })
        onMutated()
      } catch (err) {
        setError(rpcError(err))
      } finally {
        setBusyOp(null)
      }
    },
    [actor, expectedVersion, node, onMutated, scope]
  )

  const mutateTodo = useCallback(
    async (todoId, state) => {
      if (!scope) return
      setBusyTodoId(todoId)
      setError(null)
      try {
        await host.request('roadmaps.update_todo', {
          profile: scope.profile,
          project_id: scope.projectId,
          roadmap_id: scope.roadmapId,
          todo_id: todoId,
          actor: actor.trim() || 'user',
          state,
          expected_version: expectedVersion
        })
        onMutated()
      } catch (err) {
        setError(rpcError(err))
      } finally {
        setBusyTodoId(null)
      }
    },
    [actor, expectedVersion, onMutated, scope]
  )

  if (!node) {
    return jsx(EmptyState, { title: 'No node selected', description: 'Pick a node in the thread or the map.' })
  }

  const e = error && MUTATION_ERRORS[error.code] ? MUTATION_ERRORS[error.code] : null

  return jsxs('div', {
    className: 'flex flex-col gap-3',
    children: [
      jsxs('div', {
        className: 'flex items-start justify-between gap-2',
        children: [
          jsxs('div', {
            className: 'min-w-0',
            children: [
              jsxs('div', {
                className: 'text-[0.65rem] uppercase tracking-wide text-muted-foreground',
                children: [node.kind, ' · ', node.node_id]
              }),
              jsx('div', { className: 'truncate text-sm font-medium', children: nodeLabel(node) })
            ]
          }),
          jsx(NodeStateBadge, { state: node.state })
        ]
      }),

      node.description
        ? jsx('p', {
            className: 'whitespace-pre-wrap break-words text-xs leading-relaxed text-muted-foreground',
            children: node.description
          })
        : null,

      jsxs('div', {
        className: 'flex flex-wrap items-center gap-x-4 gap-y-1 text-[0.65rem] text-muted-foreground',
        children: [
          jsxs('span', { children: ['Progress: ', node.progress ?? 0, '%'] }),
          node.owner_agent ? jsxs('span', { children: ['Owner: ', node.owner_agent] }) : jsx('span', { children: 'Owner: —' }),
          node.parent_node_id ? jsxs('span', { children: ['Parent: ', node.parent_node_id] }) : null
        ]
      }),

      todos.length > 0
        ? jsxs('div', {
            className: 'flex flex-col gap-1',
            children: [
              jsx(SectionTitle, { children: 'Todos' }),
              todos.map((t) => jsx(TodoRow, { todo: t, onMutate: mutateTodo, busyTodoId }, t.todo_id))
            ]
          })
        : null,

      jsx(Separator, { className: 'my-1' }),

      // Actor + expected_version context row — always visible before acting.
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsxs('label', {
            className: 'flex items-center gap-1.5 text-[0.65rem] text-muted-foreground',
            children: [
              'Actor',
              jsx(Input, {
                value: actor,
                onChange: (ev) => setActor(ev.target.value),
                className: 'h-6 w-28 px-1.5 text-xs',
                spellCheck: false,
                'aria-label': 'Actor'
              })
            ]
          }),
          jsxs('span', {
            className: 'rounded-[3px] bg-muted px-1.5 py-0.5 font-mono text-[0.6rem] text-muted-foreground',
            children: ['expected_version = ', String(expectedVersion)]
          })
        ]
      }),

      error
        ? jsxs('div', {
            className: 'flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive',
            children: [
              jsx(Codicon, { name: 'error', size: '0.85rem', className: 'mt-px shrink-0' }),
              jsxs('div', {
                className: 'min-w-0 flex-1',
                children: [
                  jsxs('div', {
                    className: 'font-medium',
                    children: [e ? e.title : 'Error ', error.code ? `(${error.code}) ` : '', e ? '' : '']
                  }),
                  jsx('div', { className: 'mt-0.5 opacity-90', children: e ? e.hint : error.message })
                ]
              }),
              error.code === 5064 || error.code === 5065
                ? jsx(Button, {
                    type: 'button',
                    variant: 'secondary',
                    size: 'xs',
                    onClick: onMutated,
                    children: 'Reload snapshot'
                  })
                : null
            ]
          })
        : null,

      // Node actions — availability mirrors the node's lifecycle state.
      jsxs('div', {
        className: 'flex flex-wrap gap-1.5',
        children: [
          jsx(MutationButton, {
            label: 'Claim',
            codicon: 'person-add',
            busy: busyOp === 'claim_node',
            disabled: node.state !== 'ready',
            onClick: () => mutate('claim_node')
          }),
          jsxs('div', {
            className: 'flex items-center gap-1.5',
            children: [
              jsx(Input, {
                value: progressInput,
                onChange: (ev) => setProgressInput(ev.target.value.replace(/[^0-9]/g, '')),
                placeholder: '0-100',
                className: 'h-6 w-16 px-1.5 text-xs tabular-nums',
                inputMode: 'numeric',
                'aria-label': 'Progress (0-100)'
              }),
              jsx(MutationButton, {
                label: 'Set progress',
                codicon: 'arrow-up',
                busy: busyOp === 'update_progress',
                disabled: node.state !== 'in_progress' || progressInput === '',
                onClick: () => mutate('update_progress', { progress: Number(progressInput) })
              })
            ]
          }),
          jsx(MutationButton, {
            label: 'Complete',
            codicon: 'pass-filled',
            busy: busyOp === 'complete_node',
            disabled: node.state !== 'in_progress',
            onClick: () => mutate('complete_node')
          }),
          node.state === 'blocked'
            ? jsx(MutationButton, {
                label: 'Unblock',
                codicon: 'debug-restart',
                busy: busyOp === 'unblock_node',
                onClick: () => mutate('unblock_node')
              })
            : jsxs('div', {
                className: 'flex items-center gap-1.5',
                children: [
                  jsx(Input, {
                    value: reason,
                    onChange: (ev) => setReason(ev.target.value),
                    placeholder: compact ? 'reason…' : 'block reason (required)',
                    className: 'h-6 w-40 px-1.5 text-xs',
                    'aria-label': 'Block reason'
                  }),
                  jsx(MutationButton, {
                    label: 'Block',
                    codicon: 'debug-disconnect',
                    tone: 'danger',
                    busy: busyOp === 'block_node',
                    disabled: (node.state === 'ready' || node.state === 'in_progress') && !reason.trim(),
                    onClick: () => mutate('block_node', { reason: reason.trim() })
                  })
                ]
              })
        ]
      })
    ]
  })
}

// ── page ────────────────────────────────────────────────────────────────────

function RoadmapsPage() {
  const profile = useValue(host.state.profile)
  const viewport = useValue(host.state.viewport)
  const gateway = useValue(host.state.gateway)

  const [projectId, setProjectId] = useState('')
  const [roadmapId, setRoadmapId] = useState('')
  const [selectedNodeId, setSelectedNodeId] = useState('')
  const [actor, setActor] = useState('user')

  // Compact/extended: measured on the real container via ResizeObserver
  // (host.state.viewport only seeds the initial value — the app atom tracks
  // the window, not this pane).
  const containerRef = useRef(null)
  const [containerWidth, setContainerWidth] = useState(viewport?.width ?? 0)
  useEffect(() => {
    const el = containerRef.current
    const RO = globalThis.ResizeObserver
    if (!el || typeof RO !== 'function') return
    const ro = new RO((entries) => {
      for (const entry of entries) setContainerWidth(entry.contentRect.width)
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])
  const compact = containerWidth > 0 && containerWidth < 900

  // Identity guard: profile is displayed read-only; a missing profile is an
  // explicit "not initialized" state — NEVER a silent fallback to 'default'.
  const profileReady = typeof profile === 'string' && profile.trim() !== ''
  const scopeReady = profileReady && projectId !== '' && roadmapId !== ''

  // Roadmaps list — feeds both scope selectors. One query; invalidated by key.
  const listQuery = useQuery({
    queryKey: [ID, 'list', profile],
    queryFn: async () => {
      const res = await host.request('roadmaps.list', { profile })
      return res
    },
    enabled: profileReady,
    refetchInterval: 30_000
  })

  // Derive project options without clobbering the user's selection.
  const roadmaps = listQuery.data?.roadmaps ?? []
  const projectNameById = useMemo(() => {
    const m = new Map()
    for (const r of roadmaps) m.set(r.project_id, r.project_name || r.project_id)
    return m
  }, [roadmaps])
  const projects = useMemo(() => {
    const ids = [...new Set(roadmaps.map((r) => r.project_id))]
    return ids.sort((a, b) => String(a).localeCompare(String(b)))
  }, [roadmaps])
  const roadmapOptions = useMemo(
    () => (projectId === '' ? [] : roadmaps.filter((r) => r.project_id === projectId)),
    [roadmaps, projectId]
  )

  // Keep selections valid when the list refreshes under them (merge, don't
  // clobber: only clear when the value genuinely disappeared).
  useEffect(() => {
    if (projectId !== '' && !projects.includes(projectId)) setProjectId('')
  }, [projects, projectId])
  useEffect(() => {
    if (roadmapId !== '' && !roadmapOptions.some((r) => r.roadmap_id === roadmapId)) setRoadmapId('')
  }, [roadmapOptions, roadmapId])

  // Snapshot — the ONLY source of truth for the views. Loaded when the scope
  // is complete; reloaded (queryClient invalidation via key bump) after each
  // successful mutation.
  const snapshotQuery = useQuery({
    queryKey: [ID, 'steer', profile, projectId, roadmapId],
    queryFn: async () => host.request('roadmaps.snapshot', { profile, project_id: projectId, roadmap_id: roadmapId }),
    enabled: scopeReady,
    refetchInterval: 60_000
  })

  const snapshot = snapshotQuery.data
  const found = snapshot?.found === true
  const version = useMemo(() => activeVersion(snapshot), [snapshot])

  // Selection hygiene: drop a selected node that no longer exists.
  useEffect(() => {
    if (selectedNodeId !== '' && version && !version.nodes.some((n) => n.node_id === selectedNodeId)) {
      setSelectedNodeId('')
    }
  }, [version, selectedNodeId])

  const onSelect = useCallback((nodeId) => {
    setSelectedNodeId((cur) => (cur === nodeId ? '' : nodeId))
  }, [])

  const reloadSnapshot = useCallback(() => {
    void snapshotQuery.refetch()
  }, [snapshotQuery])

  const scope = scopeReady ? { profile, projectId, roadmapId } : null

  // ── guided empty states ──
  if (!profileReady) {
    return jsx(EmptyState, {
      title: 'Profile not initialized',
      description: 'No active profile identity is available. Roadmaps refuses to guess a profile (no fallback to "default").'
    })
  }

  return jsxs('div', {
    ref: containerRef,
    className: 'flex h-full min-h-0 flex-col gap-3 p-3',
    children: [
      // Scope bar: profile (read-only) → project → roadmap.
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsxs(Tip, {
            label: `Active profile (read-only) — gateway ${gateway}`,
            children: [
              jsxs('span', {
                className: 'inline-flex items-center gap-1.5 rounded-[3px] bg-muted px-2 py-1 font-mono text-[0.65rem] text-muted-foreground',
                children: [jsx(Codicon, { name: 'account', size: '0.7rem' }), profile]
              })
            ]
          }),
          jsxs('div', {
            className: 'flex items-center gap-1.5',
            children: [
              jsxs('span', { className: 'text-[0.65rem] text-muted-foreground', children: ['Project'] }),
              jsx(Select, {
                value: projectId,
                onValueChange: (v) => {
                  setProjectId(v)
                  setRoadmapId('')
                  setSelectedNodeId('')
                },
                children: [
                  jsx(SelectTrigger, {
                    className: 'h-7 w-44 text-xs',
                    'aria-label': 'Project',
                    children: jsx(SelectValue, { placeholder: 'choose…' })
                  }),
                  jsx(SelectContent, {
                    children:
                      projects.length === 0
                        ? jsx(SelectItem, { value: '__none__', disabled: true, children: 'no project' })
                        : projects.map((p) =>
                            jsx(SelectItem, { value: p, children: projectNameById.get(p) || p }, p)
                          )
                  })
                ]
              })
            ]
          }),
          jsxs('div', {
            className: 'flex items-center gap-1.5',
            children: [
              jsxs('span', { className: 'text-[0.65rem] text-muted-foreground', children: ['Roadmap'] }),
              jsx(Select, {
                value: roadmapId,
                onValueChange: (v) => {
                  setRoadmapId(v)
                  setSelectedNodeId('')
                },
                disabled: projectId === '',
                children: [
                  jsx(SelectTrigger, {
                    className: 'h-7 w-52 text-xs',
                    'aria-label': 'Roadmap',
                    children: jsx(SelectValue, { placeholder: projectId === '' ? '—' : 'choose…' })
                  }),
                  jsx(SelectContent, {
                    children:
                      roadmapOptions.length === 0
                        ? jsx(SelectItem, { value: '__none__', disabled: true, children: 'no roadmap' })
                        : roadmapOptions.map((r) =>
                            jsx(SelectItem, { value: r.roadmap_id, children: r.title || r.roadmap_id }, r.roadmap_id)
                          )
                  })
                ]
              })
            ]
          }),
          projectId !== ''
            ? jsx(CopyButton, {
                appearance: 'inline',
                text: projectId,
                label: 'Copy project ID',
                title: `Copy the project id (${projectId}) to the clipboard`
              })
            : null,
          compact
            ? null
            : jsx('span', {
                className: 'ml-auto text-[0.6rem] text-muted-foreground',
                children: `${roadmaps.length} roadmap${roadmaps.length > 1 ? 's' : ''} · profile ${profile}`
              })
        ]
      }),

      projectId !== '' && roadmapOptions.length === 0 && !listQuery.isLoading
        ? jsx(EmptyState, {
            title: 'No roadmap for this scope',
            description: `Project ${projectNameById.get(projectId) || projectId} has no roadmap in profile ${profile}. Create one backend-side (projects.db remains the source of truth).`
          })
        : null,

      // Roadmap header (title + lifecycle + version) once a roadmap is chosen.
      found && snapshot?.roadmap
        ? jsxs('div', {
            className: 'flex flex-wrap items-center gap-2 rounded-lg border border-(--ui-stroke-secondary) px-3 py-2',
            children: [
              jsxs('div', { className: 'min-w-0 flex-1', children: [
                jsx('div', { className: 'truncate text-sm font-medium', children: snapshot.roadmap.title || roadmapId }),
                snapshot.roadmap.purpose
                  ? jsx('div', { className: 'truncate text-[0.65rem] text-muted-foreground', children: snapshot.roadmap.purpose })
                  : null
              ] }),
              jsxs(Badge, { size: 'xs', variant: 'outline', children: [jsx(StatusDot, { tone: 'good' }), snapshot.roadmap.lifecycle_state] }),
              jsxs('span', { className: 'font-mono text-[0.6rem] text-muted-foreground', children: ['v', String(snapshot.roadmap.active_version)] }),
              jsx(CopyButton, {
                appearance: 'inline',
                text: `${profile} / ${projectId} / ${roadmapId}`,
                label: 'Copy scope',
                title: 'Copy the full qualified scope (profile / project / roadmap)'
              })
            ]
          })
        : null,

      jsxs('div', {
        className: cn('grid min-h-0 flex-1 gap-3', compact ? 'grid-cols-1' : 'grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)_minmax(0,0.9fr)]'),
        children: [
          // THREAD
          jsx(ScrollArea, {
            className: 'min-h-0 rounded-lg border border-(--ui-stroke-secondary) p-2',
            children: !scopeReady
              ? jsx(EmptyState, {
                  title: 'Pick a scope',
                  description: 'Select a project then a roadmap to feed the "what should I do now?" thread.'
                })
              : snapshotQuery.isLoading
                ? jsx(Skeleton, { className: 'h-24 w-full' })
                : snapshotQuery.isError
                  ? jsx(ErrorState, {
                      title: 'Snapshot unavailable',
                      description: rpcError(snapshotQuery.error).message,
                      children: jsx(Button, {
                        type: 'button',
                        size: 'xs',
                        variant: 'secondary',
                        onClick: () => void snapshotQuery.refetch(),
                        children: 'Retry'
                      })
                    })
                  : !found
                    ? jsx(EmptyState, {
                        title: 'No roadmap for this scope',
                        description: `roadmaps.snapshot → found=false for ${projectId} / ${roadmapId} in profile ${profile}.`
                      })
                    : jsx(ThreadView, { version, selectedId: selectedNodeId, onSelect, compact })
          }),

          // MAP
          jsx(ScrollArea, {
            className: 'min-h-0 rounded-lg border border-(--ui-stroke-secondary) p-2',
            children: !scopeReady
              ? jsx(EmptyState, {
                  title: 'Map waiting for a scope',
                  description: 'Canonical relations (depends_on, blocks) of the active version will appear here.'
                })
              : snapshotQuery.isLoading
                ? jsx(Skeleton, { className: 'h-24 w-full' })
                : !found || !version
                  ? jsx(EmptyState, { title: 'No active version', description: 'This roadmap has no active version to map.' })
                  : jsx(MapView, { version, selectedId: selectedNodeId, onSelect })
          }),

          // INSPECTOR
          jsx(ScrollArea, {
            className: 'min-h-0 rounded-lg border border-(--ui-stroke-secondary) p-2',
            children: !scopeReady
              ? jsx(EmptyState, {
                  title: 'Inspector inactive',
                  description: 'Select a node to see its details and trigger mutations (claim, progress, complete, block, unblock).'
                })
              : snapshotQuery.isLoading
                ? jsx(Skeleton, { className: 'h-24 w-full' })
                : !found
                  ? jsx(EmptyState, { title: 'No roadmap for this scope', description: 'Cannot inspect without a loaded snapshot.' })
                  : jsx(Inspector, {
                      snapshot,
                      version,
                      nodeId: selectedNodeId,
                      scope,
                      onMutated: reloadSnapshot,
                      compact,
                      actor,
                      setActor
                    })
          })
        ]
      })
    ]
  })
}

// ── plugin registration ─────────────────────────────────────────────────────

export default {
  id: ID,
  name: 'Roadmaps',
  description: 'Project roadmaps — "what now?" thread, canonical relation map and node inspector with versioned manual steering.',
  defaultEnabled: true,
  register(ctx) {
    ctx.registerMany([
      {
        id: 'page',
        area: ROUTES_AREA,
        data: { path: '/roadmaps' },
        render: () => jsx(RoadmapsPage, {})
      },
      {
        id: 'nav',
        area: SIDEBAR_NAV_AREA,
        order: 51,
        data: { codicon: 'milestone', label: 'Roadmaps', path: '/roadmaps' }
      }
    ])
  }
}
