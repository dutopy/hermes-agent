# Roadmaps — prototype plugin Desktop (mode disk)

Prototype du plugin « Roadmaps » pour Hermes Desktop, chargé depuis
`$HERMES_HOME/desktop-plugins/roadmaps/plugin.js` (fichier unique, ESM pur,
UI écrite avec `jsx()`/`jsxs()` de `react/jsx-runtime`). Branche de travail :
`feat/overview-roadmaps` (worktree `hermes-worktrees/overview-roadmaps`).

## Périmètre

Vertical slice **Fil + Carte + Inspecteur** sur la version active d'une roadmap :

- **Barre de scope** en haut : `project_id` puis `roadmap_id` (alimentés par
  `roadmaps.list`). Le profil actif est affiché en lecture seule ; un profil
  absent produit un état « non initialisé » explicite — jamais de fallback
  silencieux vers `default`.
- **Fil** (colonne principale) : « que faire maintenant ? » — nœuds
  `ready` / `in_progress` / `blocked` ordonnés (bloqués d'abord), avec état
  sémantique, progression, owner et `block_reason`.
- **Carte** : relations canoniques (`depends_on`, `blocks`) de la version
  active — relations actives par défaut, bascule pour inclure les inactives.
  Chaque ligne correspond à une relation réelle du snapshot ; rien de
  décoratif.
- **Inspecteur** : détails du nœud sélectionné (description, todos, parent),
  champ `actor` (défaut `user`), `expected_version` affiché (= version active
  du snapshot chargé), et les mutations `claim` / `progress` / `complete` /
  `block` / `unblock`. Les erreurs **5064** (version périmée) et **5065**
  (introuvable) proposent un bouton « Recharger le snapshot » ; la **5066**
  (transition invalide) explique l'état incompatible.
- Sélection cohérente entre les trois vues ; états vides guidés tant qu'aucun
  scope complet n'est choisi ; base vide ou `found=false` → état vide explicite
  « aucune roadmap pour ce scope » (aucune fixture).
- Compacité responsive : `ResizeObserver` sur le conteneur (seuil 900 px,
  documenté non validé visuellement), initialisé depuis `host.state.viewport`.
- Après chaque mutation réussie : rechargement autoritatif du snapshot —
  aucune mutation optimiste du cache.

## RPC utilisés (gateway JSON-RPC via `host.request`)

| Méthode | Params | Rôle |
|---|---|---|
| `roadmaps.list` | `{profile, project_id?}` | alimente les sélecteurs de scope |
| `roadmaps.snapshot` | `{profile, project_id, roadmap_id}` | source unique des trois vues |
| `roadmaps.claim_node` | scope + `node_id, actor, expected_version` | mutation |
| `roadmaps.update_progress` | idem + `progress` (0-100) | mutation |
| `roadmaps.complete_node` | idem | mutation |
| `roadmaps.block_node` | idem + `reason` (non vide) | mutation |
| `roadmaps.unblock_node` | idem | mutation |

Codes d'erreur gérés : 5063 (validation/scope), 5064 (version périmée),
5065 (introuvable), 5066 (transition invalide), 5061 (indisponible).

## Limites

- **Validation visuelle restante sur machine cible.** `node --check` passe et
  les imports/identifiants sont audités contre le SDK, mais le rendu réel
  (chargement blob, sélection de la route `/roadmaps`, états vides, compacité)
  doit être exercé dans Hermes Desktop sur la machine cible : copier ce dossier
  vers `$HERMES_HOME/desktop-plugins/roadmaps/`, puis ⌘K → « Reload desktop
  plugins ».
- Le seuil compact/étendu (900 px) est une valeur initiale, non mesurée.
- Pas d'affichage de l'historique des versions (seule la version active est
  rendue) ni d'édition du plan (mutations d'exécution uniquement).
- Le plugin n'écrit jamais dans `projects.db` directement ; toutes les écritures
  passent par les RPC versionnés.

## Non-goals (protégé par conception)

- Aucune base SQL créée, aucune écriture directe dans `projects.db`.
- Aucune donnée factice/fixture permanente.
- Aucune modification du checkout principal ; rien n'est committé.
